module Main where

import qualified M4337015
import qualified Gameplay as G

main :: IO ()
player4337015 = G.makePlayer "Big V (4337015)" M4337015.shootTheMoonStrategy
main = G.startCustom1 player4337015

