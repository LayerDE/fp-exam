module Main where

import qualified Gameplay

main :: IO ()
main = Gameplay.start

